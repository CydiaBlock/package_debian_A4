function ForecastDayNames(day){

switch (day)
  {
//Use these to translate if necessary.  Change the second values, leave the first alone.
    case "Mon": { return "Mon" }
    case "Tue": { return "Tue" }
    case "Wed": { return "Wed" }
    case "Thu": { return "Thu" }
    case "Fri": { return "Fri" }
    case "Sat": { return "Sat" }
    case "Sun": { return "Sun" }
    case "Today": { return "Today" }
    case "Tonight": { return "Tonight" }
  }

}

var Italian =
[
"Tornado",
"Tempesta Tropicale",
"Uragano",
"Temporali Forti",
"Temporali",
"Pioggia mista a Neve",
"Nevischio",
"Nevischio",
"Pioggia Gelata",
"Pioggerella",
"Pioggia Ghiacciata",
"Pioggia",
"Pioggia",
"Neve a Raffiche",
"Neve Leggera",
"Tempesta di Neve",
"Neve",
"Grandine",
"Nevischio",
"Irregolare",
"Nebbia",
"Foschia",
"Fumoso",
"Raffiche di Vento",
"Ventoso",
"Freddo",
"Nuvoloso",
"Molto Nuvoloso",
"Molto Nuvoloso",
"Parzialmente Nuvoloso",
"Parzialmente Nuvoloso",
"Sereno",
"Sereno",
"Bel Tempo",
"Bel Tempo",
"Pioggia e Grandine",
"Caldo",
"Temporali Isolati",
"Temporali Sparsi",
"Temporali Sparsi",
"Rovesci Sparsi",
"Neve Forte",
"Nevicate Sparse",
"Neve Forte",
"Parzialmente Nuvoloso",
"Rovesci Temporaleschi",
"Rovesci di Neve",
"Temporali isolati",
"Non Disponibile"
]

var English = 
[
	"Tornado",		//0	tornado
	"Tropical Storm",		//1	tropical storm
	"Hurricane",		//2	hurricane
	"Severe T-Storms",		//3	severe thunderstorms
	"Thunderstorms",		//4	thunderstorms
	"Rain & Snow",		//5	mixed rain and snow
	"Rain & Sleet",		//6	mixed rain and sleet
	"Snow & Sleet",		//7	mixed snow and sleet
	"Freezing Drizzle",		//8	freezing drizzle
	"Drizzle",		//9	drizzle
	"Freezing Rain",		//10	freezing rain
	"Showers",		//11	showers
	"Showers",		//12	showers
	"Snow Flurries",		//13	snow flurries
	"Snow Showers",		//14	light snow showers
	"Blowing Snow",		//15	blowing snow
	"Snow",		//16	snow
	"Hail", 	//17	hail
	"Sleet",		//18	sleet
	"Dust", 	//19	dust
	"Foggy",		//20	foggy
	"Haze",		//21	haze
	"Smoky",		//22	smoky
	"Blustery",		//23	blustery
	"Windy",		//24	windy
	"Cold",		//25	cold
	"Cloudy",		//26	cloudy
	"Mostly Cloudy",		//27	mostly cloudy (night)
	"Mostly Cloudy",		//28	mostly cloudy (day)
	"Partly Cloudy",		//29	partly cloudy (night)
	"Partly Cloudy",		//30	partly cloudy (day)
	"Clear",		//31	clear (night)
	"Sunny",		//32	sunny
	"Fair",		//33	fair (night)
	"Fair", 	//34	fair (day)
	"Rain & Hail", 	//35	mixed rain and hail
	"Hot",		//36	hot
	"Isolated T-Storms",		//37	isolated thunderstorms
	"Scattered T-Storms",		//38	scattered thunderstorms
	"Scattered T-Storms",		//39	scattered thunderstorms
	"Scattered Showers",		//40	scattered showers
	"Heavy Snow",		//41	heavy snow
	"Snow Showers",		//42	scattered snow showers
	"Heavy Snow",		//43	heavy snow
	"Partly Cloudy",		//44	partly cloudy
	"Thundershowers",		//45	thundershowers
	"Snow Showers",		//46	snow showers
	"Isolated T-Showers",		//47	isolated thundershowers
	"Unknown",		//3200	not available
]