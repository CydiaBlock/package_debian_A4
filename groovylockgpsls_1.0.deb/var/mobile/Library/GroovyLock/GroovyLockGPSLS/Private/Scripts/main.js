//-----------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------

var postal;

var MiniIcons =
[
	"tstorm3",		//0	tornado
	"tstorm3",		//1	tropical storm
	"tstorm3",		//2	hurricane
	"tstorm3",		//3	severe thunderstorms
	"tstorm3",		//4	thunderstorms
	"sleet",		//5	mixed rain and snow
	"sleet",		//6	mixed rain and sleet
	"sleet",		//7	mixed snow and sleet
	"sleet",		//8	freezing drizzle
	"light_rain",		//9	drizzle
	"sleet",		//10	freezing rain
	"shower3",		//11	showers
	"shower3",		//12	showers
	"snow1",		//13	snow flurries
	"snow2",		//14	light snow showers
	"snow4",		//15	blowing snow
	"snow4",		//16	snow
	"hail", 	//17	hail
	"sleet",		//18	sleet
	"mist", 	//19	dust
	"fog",		//20	foggy
	"fog",		//21	haze
	"fog",		//22	smoky
	"windy",		//23	blustery
	"windy",		//24	windy
	"windy",		//25	cold
	"overcast",		//26	cloudy
	"cloudy4_night",		//27	mostly cloudy (night)
	"cloudy4",		//28	mostly cloudy (day)
	"cloudy1_night",		//29	partly cloudy (night)
	"cloudy1",		//30	partly cloudy (day)
	"sunny_night",		//31	clear (night)
	"sunny",		//32	sunny
	"fair_night",		//33	fair (night)
	"fair", 	//34	fair (day)
	"hail", 	//35	mixed rain and hail
	"hot",		//36	hot
	"tstorm1",		//37	isolated thunderstorms
	"tstorm2",		//38	scattered thunderstorms
	"tstorm2",		//39	scattered thunderstorms
	"shower1",		//40	scattered showers
	"snow5",		//41	heavy snow
	"snow3",		//42	scattered snow showers
	"snow5",		//43	heavy snow
	"cloudy1",		//44	partly cloudy
	"tstorm3",		//45	thundershowers
	"snow2",		//46	snow showers
	"tstorm1",		//47	isolated thundershowers
	"dunno",		//3200	not available
]


function constructError (string)
{
	return {error:true, errorString:string};
}

function findChild (element, nodeName)
{
	var child;
	
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	
	return null;
}


function fetchWeatherData (callback, zip)
{
	if (isCelsius == true){
	varUnit = 'c'
	}
	else
	{
	varUnit = 'f'
	}

	url="http://xml.weather.yahoo.com/forecastrss/" //u=Farenheit, because accuWeather sucks
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function(e) {xml_loaded(e, xml_request, callback);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url+zip+'_'+varUnit+'.xml');
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null); 
	
	return xml_request;
}

function xml_loaded (event, request, callback)
{
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");//Only accounts for windChill
		
		conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text"); 
		
		obj.sunset = request.responseXML.getElementsByTagName("astronomy")[0].getAttribute("sunset");
		obj.sunset = obj.sunset.split(' ')[0]
		obj.sunsethr = obj.sunset.split(':')[0]*1+12
		obj.sunsetmin = obj.sunset.split(':')[1]
		
		obj.Today = request.responseXML.getElementsByTagName("forecast")[0].getAttribute("day");
		obj.TodayHi = request.responseXML.getElementsByTagName("forecast")[0].getAttribute("high");
		obj.TodayLo = request.responseXML.getElementsByTagName("forecast")[0].getAttribute("low");
		obj.TodayCode = request.responseXML.getElementsByTagName("forecast")[0].getAttribute("code");

		obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");

		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");

		obj.Day3 = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("day");
		obj.Day3Hi = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("high");
		obj.Day3Lo = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("low");
		obj.Day3Code = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("code");

		obj.Day4 = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("day");
		obj.Day4Hi = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("high");
		obj.Day4Lo = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("low");
		obj.Day4Code = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("code");
		callback (obj); 
	}else{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}


function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location}; //Not very clever, are we?
	callback (obj);
}

function onLoad() {



updateClock();
setInterval("updateClock();", 1000);
if (gps == true) { UpdateLocation(); }
else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
}

function weatherRefresherTemp() {
	fetchWeatherData(dealWithWeather,postal);
	setTimeout(weatherRefresherTemp, 60*1000*updateInterval);
}


function setPostal(obj) {
	if (obj.error == false){
		if(obj.cities.length > 0){
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			weatherRefresherTemp();
		}else{
			document.getElementById("city").innerText="Not Found";
		}
	}else{
		document.getElementById("city").innerText=obj.errorString;	
	}
}



function dealWithWeather(obj) {
	if (obj.error == false){
		document.getElementById("city").innerText=obj.city;
		document.getElementById("desc").innerText = LangTranslate[obj.icon*1];		
		
	if (useRealFeel == true){
			tempValue = obj.realFeel;
		}else{
			tempValue = obj.temp;
		}

		if (obj.sunsethr < currentHours) { obj.TOD = "Tonight"; }
		else if (obj.sunsethr < currentHours) { obj.TOD = "Tonight"; }
		else if (currentHours < 2) { obj.TOD = "Tonight"; }
		else { obj.TOD = "Today"; }

		document.getElementById("temp").innerHTML=tempValue+ "&#176;"
		document.getElementById("weatherIcon").src="Icon Sets/MyIcons/"+obj.icon+".png";
			

		document.getElementById("Today").innerHTML=ForecastDayNames(obj.TOD);
		document.getElementById("TodayIcon").src="Icon Sets/MyIcons/"+obj.TodayCode+".png";
		document.getElementById("TodayHiLo").innerHTML=obj.TodayHi+ "&#176; /  <font color=7d7d7d>"+obj.TodayLo+ "&#176;</font>";
				
		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1);
		document.getElementById("Day1Icon").src="Icon Sets/MyIcons/"+obj.Day1Code+".png";
		document.getElementById("Day1HiLo").innerHTML=obj.Day1Hi+ "&#176; /  <font color=7d7d7d>"+obj.Day1Lo+ "&#176;</font>";
		
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2);
		document.getElementById("Day2Icon").src="Icon Sets/MyIcons/"+obj.Day2Code+".png";
		document.getElementById("Day2HiLo").innerHTML=obj.Day2Hi+ "&#176; / <font color=#7d7d7d>"+obj.Day2Lo+ "&#176;</font>";

		document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3);
		document.getElementById("Day3Icon").src="Icon Sets/MyIcons/"+obj.Day3Code+".png";
		document.getElementById("Day3HiLo").innerHTML=obj.Day3Hi+ "&#176; / <font color=#7d7d7d>"+obj.Day3Lo+ "&#176;</font>";

		document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4);
		document.getElementById("Day4Icon").src="Icon Sets/MyIcons/"+obj.Day4Code+".png";
		document.getElementById("Day4HiLo").innerHTML=obj.Day4Hi+ "&#176;/<font color=#7d7d7d>"+obj.Day4Lo+ "&#176;</font>";
	}
	else
	{
	document.getElementById("city").innerText= "Internet ?!";
	}
}

function updateClock () {
  var this_weekday_name_array = new Array("Sunday,","Monday,","Tuesday,","Wednesday,","Thursday,","Friday,","Saturday,")
  var this_month_name_array = new Array("Jan","Feb","March","April","May","June","July","August","Sept","Oct","Nov","Dec")	    //predefine month names
  var currentTime = new Date ();
  var this_weekday = currentTime.getDay();   
  var this_date = currentTime.getDate();    
  var this_month = currentTime.getMonth();   
  currentHours = currentTime.getHours ();
  currentMinutes = currentTime.getMinutes ();
  currentSeconds = currentTime.getSeconds ();
  
  // Pad the minutes and seconds with leading zeros, if required
  currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
  currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
  
  // Choose either "AM" or "PM" as appropriate
  var timeOfDay = ( currentHours < 12 ) ? "	am" : "     pm";
  
  // Convert the hours component to 12-hour format if needed
  //currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  
  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  
  // Compose the string for display
  var currentTimeString = currentHours + ":" + currentMinutes;
  
  // Update the time display
  document.getElementById("clock").innerHTML = currentTimeString;
  document.getElementById("calendar").innerHTML = this_weekday_name_array[this_weekday] + " " + this_month_name_array[this_month] + " " + this_date  //concat long date string

}

