// Options

var gps = true;

var locale = "38671"; //e.g. 'Defiance, Ohio'|'Moscow, Russia'|'Ledyard, AT'|'London, UK'|"USNY0996"

var LangTranslate = English; // or Italian

// Set to 'false' if you'd prefer Farenheit
var isCelsius = false; //true|false

// Use 'Real Feel' temperatures where possible, taking into account Wind Chill, Humidity etc.
var useRealFeel = false; //true|false

// Please endeavour to set this to a sensible value if you really must change it...
var updateInterval = 15; //Minutes
