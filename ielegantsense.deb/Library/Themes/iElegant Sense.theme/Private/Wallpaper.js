var postal;
var demoMode = false;
var enabled;

if (location.href.indexOf("Wallpaper")	> 0){
	stylesheet = stylesheetLock;
	iconSet = iconSetLock;
	iconExt = iconExtLock;
	enabled = enableLockScreen;
}else{
	stylesheet = stylesheetWall;
	iconSet = iconSetWall;
	iconExt = iconExtWall;
	enabled = enableWallpaper;
}

if(enabled == true){
if(iconSet == null || iconSet == 'null' || iconSet == ""){
	var iconSet = stylesheet;
}

var headID = document.getElementsByTagName("head")[0];	       
var styleNode = document.createElement('link');
styleNode.type = 'text/css';
styleNode.rel = 'stylesheet';
styleNode.href = 'Stylesheets/'+stylesheet+'.css';
headID.appendChild(styleNode);

var scriptNode = document.createElement('script');
scriptNode.type = 'text/javascript';
scriptNode.src = 'Sources/'+source+'.js';
headID.appendChild(scriptNode);
}

function onLoad(){
	if (enabled == true){ 
	if (demoMode == true){
		document.getElementById("weatherIcon").src="IconSets/"+iconSet+"/"+"cloudy1"+iconExt;
		document.getElementById("city").innerText="Somewhere";
		document.getElementById("desc").innerText="Partly Cloudy";
		document.getElementById("temp").innerText="100�";		
		document.getElementById("forecast").innerText="Sun";	
	}else{ 
	document.getElementById("weatherIcon").src="IconSets/"+iconSet+"/"+"dunno"+iconExt;
	validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)
	}
	}else{
		document.getElementsByTagName("body")[0].innerText='';
	}
}

function convertTemp(num)
{
	if (isCelsius == true)
		return Math.round ((num - 32) * 5 / 9);
	else
		return num;
}

function setPostal(obj){
	
	if (obj.error == false){
		if(obj.cities.length > 0){
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			document.getElementById("WeatherContainer").className = "";	
			weatherRefresherTemp();
		}else{
			document.getElementById("city").innerText="Not Found";
			document.getElementById("WeatherContainer").className = "errorLocaleNotFound";	
		}
	}else{
		document.getElementById("city").innerText=obj.errorString;
		document.getElementById("WeatherContainer").className = "errorLocaleValidate";	
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
	}
}

function dealWithWeather(obj){
	var translatedesc="description";
		
	if (obj.error == false){
		document.getElementById("city").innerText=obj.city;
		document.getElementById("desc").innerText=obj.description.toLowerCase();
		
		if(useRealFeel == true){
			tempValue = convertTemp(obj.realFeel);
		}else{
			tempValue = convertTemp(obj.temp)
		}
		document.getElementById("temp").innerText=tempValue+"º";
		document.getElementById("weatherIcon").src="IconSets/"+iconSet+"/"+MiniIcons[obj.icon]+iconExt;
		document.getElementById("desc").innerText=Francais[obj.icon];
		translatedesc=obj.description.toLowerCase();


		
		/*ProductRed*/
		lastResults = new Array;
		lastResults[0] = {hi:obj.hi, lo:obj.lo, now:obj.temp};
		var c = obj.forecast.length;

		if (c > 6) c = 6; // just to be safe
		for (var i=0; i<c; ++i)
		{
			var forecast = obj.forecast[i];

			document.getElementById('hi'+i).innerText = convertTemp(forecast.hi)+"º";;
			document.getElementById('low'+i).innerText = convertTemp(forecast.lo)+"º";;
			
			lastResults[i+1] = {hi:forecast.hi, lo:forecast.lo};

		}
		/*ProductRed*/

		document.getElementById("WeatherContainer").className = "";	

		
	}else{
		//Could be down to any number of things, which is unhelpful...
		document.getElementById("WeatherContainer").className = "errorWeatherDataFetch";	
	}
	
var this_weekday_name_array = new Array("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
var this_month_name_array = new Array(" ," "," "," "," "," "," "," "," "," "," "," ")	   //predefine month names
var this_date_timestamp = new Date()
var this_weekday = this_date_timestamp.getDay()
var this_date = this_date_timestamp.getDate()
var this_month = this_date_timestamp.getMonth()
var this_year = this_date_timestamp.getYear()

if (this_year < 1000)
    this_year+= 1900;
if (this_year==101)
    this_year=2001;

document.getElementById("date").innerText=this_weekday_name_array[this_weekday] + ", " + this_month_name_array[this_month] + " " + this_date  
	
}

function weatherRefresherTemp(){ //I'm a bastard ugly hack. Hate me.
	fetchWeatherData(dealWithWeather,postal);
	setTimeout(weatherRefresherTemp, 60*1000*updateInterval);
}
