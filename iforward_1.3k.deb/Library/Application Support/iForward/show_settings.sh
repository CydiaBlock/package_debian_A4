#!/bin/bash
cp /Library/Application\ Support/iForward/iForward_bk.plist /Library/PreferenceLoader/Preferences/iForward.plist
killall SpringBoard
