﻿// WeatherWidget.theme
// Produced by Adam Watkins (http://www.stupidpupil.co.uk)

// The location field should be a relatively machine-legible string
// if using the default, Apple/AccuWeather parser (originally from Leopard's Weather.wdgt)
var locale = "Ho Chi Minh City, Vietnam" //e.g. 'Defiance, Ohio'|'Moscow, Russia'|'Ledyard, AT'|'London, UK'|"VMXX0007"

// Set to 'false' if you'd prefer Farenheit
var isCelsius = true //true|false

// Use 'Real Feel' temperatures where possible, taking into account Wind Chill, Humidity etc.
var useRealFeel = false //true|false

/**/

// Supplied styles are 'originalBubble', 'myopia', 'iconOnly' and 'split'.
// (Add your own to the CSS folder!)
var stylesheet = 'style' //'originalBubble'|'myopia'|'iconOnly'|'split'

// The supplied icon set is 'klear'
// Images must follow the same naming schema as the 'klear' set (borrowed from KWeather)
var iconSet = "droid" //'klear'|'tango'|null (null makes iconSet = stylesheet)
var iconExt = ".png" //'.png'|.'gif' etc.

/**/

// The other available source is 'yahooWeather' which for the 'locale'
// requires a US zip or location code (e.g. UKXX0085 or CHXX0008) from http://weather.yahoo.com
var source = 'appleAccuweatherStolen' //'appleAccuweatherStolen'|'yahooWeather'

// Please endeavour to set this to a sensible value if you really must change it...
var updateInterval = 60 //Minutes