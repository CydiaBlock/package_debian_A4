var postal;

if(iconSet == null || iconSet == 'null'){
	var iconSet = stylesheet;
}

var headID = document.getElementsByTagName("head")[0];         
var styleNode = document.createElement('link');
styleNode.type = 'text/css';
styleNode.rel = 'stylesheet';
styleNode.href = './CSS/'+stylesheet+'.css';
headID.appendChild(styleNode);

var scriptNode = document.createElement('script');
scriptNode.type = 'text/javascript';
scriptNode.src = './scripts/'+source+'.js';
headID.appendChild(scriptNode);

function onLoad(){ 
	document.getElementById("weatherIcon").src="./images/"+iconSet+"/"+"dunno"+iconExt;
	validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)
}

function convertTemp(num)
{
	if (isCelsius)
		return Math.round ((num - 32) * 5 / 9);
	else
		return num;
}

function setPostal(obj){
	
	if (obj.error == false){
		if(obj.cities.length > 0){
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			fetchWeatherData(dealWithWeather,postal);
		}else{
			document.getElementById("city").innerText="Not Found";
		}
	}else{
		document.getElementById("city").innerText=obj.errorString;	
	}
}

function dealWithWeather(obj){

	if (obj.error == false){
		document.getElementById("city").innerText=obj.city;
		document.getElementById("desc").innerText=obj.description.toLowerCase();
		
		if(useRealFeel == true){
			tempValue = convertTemp(obj.realFeel);
		}else{
			tempValue = convertTemp(obj.temp)
		}
		document.getElementById("temp").innerHTML=tempValue+ "&#176;";
		document.getElementById("weatherIcon").src="./images/"+iconSet+"/"+MiniIcons[obj.icon]+iconExt;
	}
	
	setTimeout('fetchWeatherData(dealWithWeather,postal)', 1000*60*updateInterval);
}