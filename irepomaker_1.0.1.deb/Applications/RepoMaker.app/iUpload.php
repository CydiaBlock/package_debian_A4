<html>
	<head><meta name="author" content="Dave1482" /> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no;" /> <meta charset="utf-8"> <meta http-equiv="Content-type" content="text/html;charset=UTF-8"> <meta content="yes" name="apple-mobile-web-app-capable" /> <meta content="text/html; charset=utf-8" http-equiv="Content-Type" /> <meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" /> <style rel="stylesheet" media="screen" type="text/css"> body{         position: relative;         margin: 0;         -webkit-text-size-adjust: none;         min-height: 416px;         font-family: Helvetica,sans-serif;         background: #555555;         background-color:#555555;         -webkit-touch-callout: none; } #topbar {          position: relative;         left: 0;         top: 0;         height: 44px;         width: auto;         margin-bottom: 13px;  } #title {         position: absolute;         top: 0;         left: 0;         right: 0;          padding: 0 10px;         text-align: center;         text-overflow: ellipsis;         white-space: nowrap;         overflow: hidden;         height: 44px;         line-height: 44px;         border-top: 2px solid #00FFFF;         border-bottom: 2px solid #00FFFF;         color: #FFFFFF;         text-shadow: #000000 0 -1px 0;         font-size: 16pt; } #content {         width: 99%;         position: relative;         left: 1%;         word-wrap: break-all;         white-space: normal;         min-height: 250px;         margin-top: 10px;         height: auto;         z-index: 0;         overflow: hidden; } a:link { COLOR: #00FFFF; } a:visited { COLOR: #00FF00; } a:active { COLOR: #00FF00; } 
		.error {
			font-weight: bold;
			color: #FF0000;
		}</style> <title>Repo Maker Server: File Uploaded</title>
	</head>
	<body><div id="topbar">
<div id="title">Repo Maker Server: iUpload</div></div>
<div id="content"><font color="#FFFFFF"><center>
<?php

	$target_path = "/var/root/Library/RepoMaker/files/Uploaded/";
	$target_path = $target_path . basename ($_FILES['up_file']['name']); 

	if (move_uploaded_file ($_FILES['up_file']['tmp_name'], $target_path)) {

?>

	<p>The file has been succesfully uploaded to <a href="/var/root/Library/RepoMaker/files/Uploaded/">/var/root/Library/RepoMaker/files/Uploaded/</a>.</p>
	
<?php

	} else {
	
?>

	<p class="error">An error was encountered while uploading the file.</p>

<?php
	
	}

?>

	<p><a href="/">Home</a> <a href="iUpload.html">Upload another file</a></p>
	</center></font></div></body>
</html>
