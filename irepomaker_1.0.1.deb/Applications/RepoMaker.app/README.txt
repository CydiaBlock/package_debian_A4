This folder is where you will find packages in the "repo" folder to upload, along with a "files" folder used to package files into a .deb file.

Things to remember:

1) For Apps (folders with .app extension), there is a folder in the "files" folder named "Apps", and in there, another folder named "Applications".  Put the app in there.

2) For WinterBoard Themes (folders with .theme extension), there is a folder in the "files" folder named "Themes", in that there's another folder named "Library" and in that folder is another folder named "Themes".  Put the theme in there.

3) Anything else will have to go in the "Other" folder.

4) All finished deb files will be in the "debs" folder.

5) Any packages you want in your repo will be in the "repo" folder.