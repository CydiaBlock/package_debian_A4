function imageSourceFromPoint(x, y){
    var element = document.elementFromPoint(x, y);
    if(element.src){
        return element.src;
    }
    return null;
}