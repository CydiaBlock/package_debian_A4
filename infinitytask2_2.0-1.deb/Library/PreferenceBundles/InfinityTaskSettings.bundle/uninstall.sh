#!/bin/bash

rm -f /Library/MobileSubstrate/DynamicLibraries/InfinityTask*
rm -f /Library/PreferenceLoader/Preferences/InfinityTask.plist
rm -fr /Library/Switches/InfinityTask_OpenTabBG.bundle
killall assertiond backboardd SpringBoard
