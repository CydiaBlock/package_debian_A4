#!/bin/bash

killall assertiond backboardd SpringBoard
