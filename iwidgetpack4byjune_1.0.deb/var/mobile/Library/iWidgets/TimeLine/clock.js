function updateClock (){

var TwentyFourHourClock = localStorage.getItem('api24hr');


  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );
  var currentMinutes = currentTime.getMinutes ( );
  var currentSeconds = currentTime.getSeconds ( );

    currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
    currentHours = ( currentHours == 0 ) ? 12 : currentHours;
    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;

if (TwentyFourHourClock == "false"){

}

  else{
      var timeOfDay = ( currentHours < 12 ) ? " " : " "
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  }

  /*for leading zero on non 24hr delete this line*
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;

/*-----------------------------------------------------------------------------------------------------------------------------------------------*/

  // Compose the string for display
  var currentTimeString = currentHours + ":";
  var currentTimeString1 = currentMinutes;

  // Update the time display
document.getElementById("hours").firstChild.nodeValue = currentTimeString+currentTimeString1;

}
function init2 ( )
{
  timeDisplay = document.createTextNode ( "" );
  document.getElementById("ampm").appendChild ( timeDisplay );
}

function amPm ( )
{
  var currentTime = new Date ( );
  var currentHours = currentTime.getHours ( );


/*---------------------------------------------------------------------------------------------------------------------------------AM PM Edit------*/

/* Remove the /* from under this line to display am or pm after the 12 hours clock */  /* NEW!! */

  // Choose either "AM" or "PM" as appropriate
  var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
  // Convert the hours component to 12-hour format if needed
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  // Convert an hours component of "0" to "12"
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  // Compose the string for display
  var currentTimeString = timeOfDay;
  // Update the time display
document.getElementById("ampm").firstChild.nodeValue = currentTimeString;
}

function calendarDate (){
var date = new Date();
  var day = date.getDay();
  var datetoday=date.getDate();
  var year=date.getFullYear();
  var monthnum=date.getMonth();
  var name = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][day];
  var month=["January","Feburary","March","April","May","June","July","August","September","October","November","December"][monthnum];

  document.getElementById("date").innerHTML = '<span>' + name +", "+ month +" "+ day+'</span>';
}
// -->
