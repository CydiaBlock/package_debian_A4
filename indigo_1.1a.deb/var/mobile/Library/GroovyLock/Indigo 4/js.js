$(document).ready(function() {

    //color stuff
    if (darkMode) {
      $('#top').css({'color':'black'});
      $('#line').css({'background-color':'black'});
      var dayColor = 'rgba(0,0,0,0.8)';
    }
    else {
      $('html').css({'color':'white'});
      $('#line').css({'background-color':'white'});
      var dayColor = 'rgba(255,255,255,0.8)';
    }

setInterval(function() {
    //Date stuff
    var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

    // Create a newDate() object
    var newDate = new Date();
    // Extract the current date from Date object
    newDate.setDate(newDate.getDate());
    // Output the day, date, month and year
    var day = dayNames[newDate.getDay()];
    var num = newDate.getDate();
    var month = monthNames[newDate.getMonth()];
    $('#date').html( '<a id="opacity" style="color:'+ dayColor +'">' + day.toUpperCase().substring(0,3) + '</a> '+ '&nbsp;' + num + '&nbsp; ' + '<a id="opacity" style="color:'+ dayColor +'">' + month.toUpperCase().substring(0,3)+'</a>' );

}, 500 );

// time stuff
if (twelve == false) {
    setInterval(function() {
        // Create a newDate() object and extract the minutes of the current time on the visitor's
        var minutes = new Date().getMinutes();
        // Add a leading zero to the minutes value
        $("#m").html((minutes < 10 ? "0" : "") + minutes);
    }, 100);

    setInterval(function() {
        // Create a newDate() object and extract the hours of the current time on the visitor's
        var hours = new Date().getHours();
        // Add a leading zero to the hours value
        $("#h").html((hours < 10 ? "0" : "") + hours);
    }, 100);
} else if (twelve == true){
  $('#time').css({'padding-left':'10px'});
  setInterval(function() {
      // Create a newDate() object and extract the minutes of the current time on the visitor's
      var minutes = new Date().getMinutes();
      var hours = new Date().getHours();
      suffix = (hours >= 12)? 'PM' : 'AM';
      // Add a leading zero to the minutes value
      $("#m").html((minutes < 10 ? "0" : "") + minutes + '<span id="suffix">' + suffix + '</span>');
  }, 100);

  setInterval(function() {
      // Create a newDate() object and extract the hours of the current time on the visitor's
      var hours = new Date().getHours();

      //only -12 from hours if it is greater than 12 (if not back at mid night)
      hours = (hours > 12)? hours -12 : hours;

      //if 00 then it is 12 am
      hours = (hours == '00')? 12 : hours;
      // Add a leading zero to the hours value
      $("#h").html(hours);
  }, 100);
}

});
