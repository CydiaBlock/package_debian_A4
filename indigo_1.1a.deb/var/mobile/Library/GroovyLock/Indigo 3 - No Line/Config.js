var darkMode = false; // On for dark text
var twelve = false; // On for twelve hour clock
