#define MPEG4IP_PACKAGE "mpeg4ip"
#define MPEG4IP_VERSION "1.1.3"
