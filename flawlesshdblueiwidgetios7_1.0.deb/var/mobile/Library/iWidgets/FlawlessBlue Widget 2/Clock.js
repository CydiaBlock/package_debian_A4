function clock(){
	var now = new Date();
	var h = now.getHours();
	var m = now.getMinutes();	
	var s = now.getSeconds();
	var mil = now.getMilliseconds();
	var throughHour = findThrough('hour', m);
	var throughMin = findThrough('min', s);
	var hRotate = (h*30)+throughHour;
	var mRotate = (m*6)+throughMin;
	var sRotate = s*6;
	var month = new Array(' ',' ',' ',' ',' ',' ',' ');
	var date = now.getDate();
	document.getElementById('hourHand').style.webkitTransform = "rotate("+hRotate+"deg)";
	document.getElementById('minuteHand').style.webkitTransform = "rotate("+mRotate+"deg)";
	document.getElementById('secondHand').style.webkitTransform = "rotate("+sRotate+"deg)";
	document.getElementById('day').textContent = month[now.getDay()];
	document.getElementById('date').textContent = date;
}
function findThrough(unit, val){
	if (val == 0) return 0;
	var working = (1/(60/val))*100;
	if (unit == 'hour') return Math.floor((6/100)*working)*6;
	return Math.floor((6/100)*working);
}
function init() {
	clock();
	setInterval("clock()", 1000);
}